Drop these into repo root of blackshell-final-cut (overwrite):
  pages/models.py
  templates/partials/capability_card.html
  templates/pages/projects.html
  templates/pages/project_detail.html

Commit: fix: fall back to static stock photos when media 404s
Then wait for Railway deploy and hard-refresh https://blackshelltech.com
